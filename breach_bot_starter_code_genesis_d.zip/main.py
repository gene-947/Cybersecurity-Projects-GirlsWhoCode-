#Breach Bot Starter Code
hongKongBreach = 2017

#Greets user
print("Hello! I'm Breach Bot.")
userName = input("What is your name?\n")
print("Nice to meet you " + userName)

#Recounts start of the breach
todaysYear = input("What year is it?\n")
timePassed = int(todaysYear) - hongKongBreach
if timePassed < 0:
    print("I'm sorry, but I don't believe that's the right year.")
elif timePassed == 0:
    print("Wow, the Hong Kong Registration and Electoral Office data breach happened this year!")
else:
    print("Woah, its been " + str(timePassed)+ " years since the Hong Kong Registration and Electoral Office data breach in 2017.")
#Introduces CIA Triad

print("Would you like to learn about the Hong Kong Registration and Electoral Office data breach in 2017?")
giveInfo = input("Type 'yes' or 'no'\n")

#Explains the breach
while giveInfo.lower() == "yes":
  print("What would you like to learn more about? Enter the lowercase letter of the following options: \n(a) breach details, (b) organization's response, or (c)  I would like to hear your reflection.")
  topic = input()
  
  if topic.lower() == "a":
    print("The Hong Kong Electoral Office had two computers with voter information and electoral committee member names already publicly available, the breach stole voter ID card numbers, addresses, and phone numbers, although the exact number of voters affected is unknown, it's possibly up to 3.7 million. The thief managed to get into Hall 7’s room, which required a passcode and an access entry card, and stole both computers.")
  
  elif topic.lower() == "b":
    print("In response to the data breach, Hong Kong immediately got a new chief executive and launched an investigation into the incident, although no findings were disclosed, and not only that but in the years following that Hong Kong became much stricter about data misuse and protection, charging fines. Despite this, Hong Kong’s Electoral Office never recommended that affected users to do anything even with their data stolen.")
  
  elif topic.lower() == "c":
    break
  
  else:
    print("Sorry, I didn't catch that. Choose one of the options listed.")
  
  input("Press enter to continue\n")
#Introduces my take
print("\nI'm excited to share my perspective with you. Are you ready to hear my take?")
giveInfo = input("Type 'yes' or 'no'\n")

#Shares my take
while giveInfo.lower() == "yes":
  print("What would you like to learn more about? Enter the lowercase letter of the following options: \n(a) relation to CIA Triad, (b) my reaction, (c) my advice, or (d) none")
  topic = input()
  
  if topic.lower() == "a":
    print("After the incident, Hong Kong became stricter with data usage charging fines if the data was used wrong. This connects to the CIA Triad pillar of Integerity because it ensures that people’s data is being handled correctly and by the right people.")
  
  elif topic.lower() == "b":
    print("We disagree with the organization's response because the Hong Kong Electoral Office could’ve done more to ensure this never happened again by adding more security on the data instead of just two levels of security.")
  
  elif topic.lower() == "c":
    print("I would convince victims to take action by telling them their phones can be hacked and their other personal information can be stolen. My advice would be to change phone numbers, get a new one.")

  elif topic.lower() == "d":
      print("Alright, thats okay then.")
      break
  else:
    print("Sorry, I didn't catch that. Choose one of the options listed.")
  
  input("Press enter to continue\n")


#Chatbot ends conversation
print("Thanks for chatting with me, and I hope you learned something new!")