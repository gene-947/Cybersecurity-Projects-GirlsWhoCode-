#CyHelp Starter Code
creationDate = 1970

#Greets user
print("Hello! I'm CyHelp.")
userName = input("What is your name? \n")
print("Its incredible to me you " + userName)


#Recounts start of Cybersecurity
todayYear = input("What year is it?")
timePassed = int(todayYear) - creationDate
print("Woah, thats a long time! It's been " + str(timePassed) + " since the creation of cybersecurity!")
print("")
print("The field of Cybersecurity started in the 1970s when more and more information started being stored on computer systems and networks!")
input("\n Please press enter to continue. \n")

#Describes Cybersecurity
print("Cybersecurity refers to the practices that people use to protect computer systems and networks from cyber attacks.")
print("These people can be governments/nations, individuals, companies, community organizations, and hackers. \n")


#Introduces CIA Triad
print("The CIA Triad is the model used to discuss cybersecurity. CIA stands for confidentiality, integrity, availablity.")
print("Would you like to learn about the CIA triad?")
giveInfo = input("\n Type in 'yes' or 'no' please and thank you")

#Explains pillars of CIA Triad
while giveInfo.lower() == "yes":
    
    print("What would you like to learn more about? Enter the lowercase letter of the following options: \n(a) confidentiality, (b) integrity, (c) availability, or (d) none")
    choice = input()
    if choice.lower() == "a":
        print("Confidentiality makes sure data is private.")
    elif choice.lower() == "b":
        print("Integrity makes sure data has not been tampered with and can be trusted.")
    elif choice.lower() == "c":
        print("Availability makes sure authorized people can access the data.")
    elif choice.lower() == "d":
        print("Alright then, thats okay.")
        break
    else:
        print("Pardon? I'm sorry but I don't believe that's one of the options listed. Please choose one of the options listed.")
#input("\n Please press enter to continue. \n")

#Chatbot ends conversation
print("Thanks for chatting with me, and I hope you learned something new!")